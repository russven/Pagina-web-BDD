// Importar dependencias necesarias
const express = require("express"); // Framework para crear y configurar el servidor web
const mongoose = require("mongoose"); // Biblioteca para interactuar con MongoDB
const cors = require("cors"); // Middleware para habilitar el intercambio de recursos entre dominios
require("dotenv").config(); // Cargar variables de entorno desde un archivo .env

// Crear instancia del servidor de Express
const app = express();

// Middleware para analizar las solicitudes JSON
app.use(express.json());

// Middleware para permitir solicitudes desde diferentes orígenes (CORS)
app.use(cors());

// Conexión con la base de datos de MongoDB usando la URI del archivo .env
const mongoUri = process.env.MONGODB_URI; // Recupera la URL de conexión desde el archivo .env
mongoose.connect(mongoUri, {
    useNewUrlParser: true, // Usa el nuevo analizador de URL de MongoDB
    useUnifiedTopology: true, // Usa el nuevo motor de administración de conexiones
})
    .then(() => console.log("Conexión exitosa a MongoDB")) // Mensaje si la conexión es exitosa
    .catch((error) => console.error("Error al conectar a la base de datos:", error)); // Mensaje si hay error

// Crear un modelo de Mongoose para la colección "users"
const User = mongoose.model("users", new mongoose.Schema({
    name: { type: String, required: true }, // Campo obligatorio para el nombre del usuario
    email: { type: String, required: true }, // Campo obligatorio para el correo electrónico
    password: { type: String, required: true }, // Campo obligatorio para la contraseña
}));

// Rutas para el CRUD

// Ruta para obtener todos los usuarios
// GET http://localhost:5007/users
app.get("/users", async (req, res) => {
    const users = await User.find(); // Busca todos los documentos en la colección "users"
    res.json(users); // Devuelve los usuarios como JSON
});

// Ruta para crear un nuevo usuario
// POST http://localhost:5007/users
app.post("/users", async (req, res) => {
    const newUser = new User(req.body); // Crea un nuevo documento con los datos del cuerpo de la solicitud
    await newUser.save(); // Guarda el documento en la base de datos
    res.status(201).json(newUser); // Devuelve el usuario creado con código 201 (Creado)
});

// Ruta para actualizar un usuario existente
// PUT http://localhost:5007/users/:id
app.put("/users/:id", async (req, res) => {
    const updatedUser = await User.findByIdAndUpdate(
        req.params.id, // Obtiene el ID del usuario desde la URL
        req.body, // Nuevos datos para actualizar
        { new: true } // Devuelve el documento actualizado en lugar del original
    );
    res.json(updatedUser); // Devuelve el usuario actualizado como JSON
});

// Ruta para eliminar un usuario existente
// DELETE http://localhost:5007/users/:id
app.delete("/users/:id", async (req, res) => {
    await User.findByIdAndDelete(req.params.id); // Elimina el documento con el ID especificado
    res.status(204).send(); // Devuelve una respuesta sin contenido para indicar éxito
});

// Configurar el puerto del servidor
const PORT = process.env.PORT || 5174; // Usa el puerto definido en .env o 5174 por defecto

// Iniciar el servidor en el puerto especificado
app.listen(PORT, () => {
    console.log(`Servidor funcionando en el puerto ${PORT}`); // Mensaje indicando que el servidor está en ejecución
});

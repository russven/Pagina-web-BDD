const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

// Conectar a MongoDB
mongoose.connect('mongodb://localhost:27017/myDatabase', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log('Conectado a MongoDB'))
  .catch(err => console.error('Error al conectar a MongoDB:', err));

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Definir esquema y modelo para los datos
const DataSchema = new mongoose.Schema({
    // Define los campos de tu esquema según los datos esperados
    name: String,
    age: Number,
    email: String,
}, { timestamps: true });

const DataModel = mongoose.model('Data', DataSchema);

// Endpoint para recibir datos del cliente
app.post('/api/sync', async (req, res) => {
    try {
        const newData = new DataModel(req.body);
        const savedData = await newData.save();
        res.status(201).json({ message: 'Datos guardados con éxito', data: savedData });
    } catch (error) {
        res.status(500).json({ message: 'Error al guardar los datos', error });
    }
});

// Iniciar servidor
const PORT = 5173;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT})`);
});
